print("Hello World!")

first_name = "Tara"
print("Hello", first_name)
print("Hello " + first_name)

fav_num = 8
print("Hello", str(fav_num))
print("Hello " + str(fav_num))

fav_food1 = "Smoothies"
fav_food2 = "Acai Bowl"
print("I love to eat {} and {}!".format(fav_food1, fav_food2))
print(f"I love to eat {fav_food1} and {fav_food2}!")